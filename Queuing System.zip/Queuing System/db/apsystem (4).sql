-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 20, 2018 at 08:07 AM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `apsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(60) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `photo` varchar(200) NOT NULL,
  `created_on` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `firstname`, `lastname`, `photo`, `created_on`) VALUES
(1, 'nurhodelta', '$2y$10$fCOiMky4n5hCJx3cpsG20Od4wHtlkCLKmO6VLobJNRIg9ooHTkgjK', 'Neovic', 'Devierte', 'facebook-profile-image.jpeg', '2018-04-30'),
(2, 'jpacia', '$2y$10$fCOiMky4n5hCJx3cpsG20Od4wHtlkCLKmO6VLobJNRIg9ooHTkgjK', 'Janrenzo', 'Pacia', 'facebook-profile-image.jpeg', '2018-04-30'),
(3, 'jdelosreyes', '$2y$10$PNRUPexnXBe3yLajFBIW6uTOQrQPqU3xoZ77Kftlj/LWhwYxJ8Nza', 'Jason', 'Delos Reyes', 'jd.jpg', '2018-04-30'),
(4, 'jcordova', '$2y$10$LaWWi1.XlUpUKQtLPMlnHeUYWsjen9evnMaByNITGBOGuR2JBPY5u', 'Jerico', 'Cordova', 'indexss.jpg', '2018-04-30'),
(5, 'jhilardino', '$2y$10$f86QEm76Sg0RzXLm80VrPeWigLAai32vSguffm265OT0Hj6KecF/q', 'Jay Bryan', 'HIlardino', 'khazix-dark-star.jpg', '2018-04-30');

-- --------------------------------------------------------

--
-- Table structure for table `application_info`
--

CREATE TABLE `application_info` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact_info` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `application_info`
--

INSERT INTO `application_info` (`id`, `firstname`, `middlename`, `lastname`, `address`, `contact_info`) VALUES
(1, 'Joshua', 'Guarra', 'Dignadice', 'Bago City', '09123456789');

-- --------------------------------------------------------

--
-- Table structure for table `forms_info`
--

CREATE TABLE `forms_info` (
  `id` int(11) NOT NULL,
  `request_type` varchar(255) NOT NULL,
  `payment` double NOT NULL,
  `duration` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forms_info`
--

INSERT INTO `forms_info` (`id`, `request_type`, `payment`, `duration`) VALUES
(1, 'Form 137', 1000, '15 Days');

-- --------------------------------------------------------

--
-- Table structure for table `request_form_info`
--

CREATE TABLE `request_form_info` (
  `id` int(11) NOT NULL,
  `transaction_id` int(25) NOT NULL,
  `date_request` date NOT NULL,
  `app_info_id` int(25) NOT NULL,
  `req_form_id` int(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `request_form_info`
--

INSERT INTO `request_form_info` (`id`, `transaction_id`, `date_request`, `app_info_id`, `req_form_id`) VALUES
(1, 2015107477, '2018-10-01', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `id` int(11) NOT NULL,
  `date_release` date NOT NULL,
  `req_info_id` int(11) NOT NULL,
  `req_status` varchar(255) NOT NULL,
  `payment_status` varchar(255) NOT NULL,
  `remarks` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`id`, `date_release`, `req_info_id`, `req_status`, `payment_status`, `remarks`) VALUES
(1, '2018-10-24', 1, 'Processed', 'Unpaid', ''),
(2, '2018-10-24', 1, 'Processed\r\n', 'Paid', ''),
(3, '2018-10-24', 1, 'Declined', 'Unpaid', 'No Records Found'),
(4, '2018-10-24', 1, 'Pending', 'Unpaid', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `application_info`
--
ALTER TABLE `application_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `forms_info`
--
ALTER TABLE `forms_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `request_form_info`
--
ALTER TABLE `request_form_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `application_info`
--
ALTER TABLE `application_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `forms_info`
--
ALTER TABLE `forms_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `request_form_info`
--
ALTER TABLE `request_form_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
