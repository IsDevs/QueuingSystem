<?php

include 'config/config.php';

include 'classes/class.students.php';

include 'classes/class.site.global.php';

$student = new Students();

$site=new Site();

?>



<!DOCTYPE html>

<html>

<head>

	<title>Register - <?php echo $site->getTitle(); ?></title>

	<link rel="icon" type="image/png" href="favicon.ico">

	<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
	
    <link rel="stylesheet" type="text/css" href="css/stylesheet.css">

    <link rel="stylesheet" href="css/responsive-stylesheet.css">

	<script src="https://apis.google.com/js/platform.js" async defer></script>

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

	<script src="script/script.js"></script>

</head>

<body>

	<div style="padding:15px;">

		<img src="images/usls.png" style="width: 100%; min-height: 10px;"></br></br></br>

		<?PHP

		$st_smsCode = $_POST['smsCode'];

		$st_id = $_POST['stud_id'];

		$st_firstname = $_POST['stud_firstname'];

		$st_middlename = $_POST['stud_middlename'];

		$st_lastname = $_POST['stud_lastname'];

		$st_gender = $_POST['stud_gender'];

		$st_dob = $_POST['stud_dob'];

		$st_email = $_POST['stud_email'];

		$st_hpnumber = $_POST['stud_hpnumber'];

		$st_address = $_POST['stud_address'];

		$st_section = $_POST['stud_section'];

		$st_instructor = $_POST['stud_instructor'];

		$st_subject = $_POST['stud_subject'];

		

		/*------------------------------------------------------------------------------------*\

		 * This section is for sms engine sending One-Time-Authentication(OTA) during sign up *

		\*------------------------------------------------------------------------------------*/

		$serverurl=$site->getSmsServerUrl(); //moved server globally at classes/class.site.global.php

		$message="Your Verification code is: $st_smsCode.\nYou requested this one-time-authentication(OTA) from www.usls.cf.\nThis is a computer generated message.\nNo need reply!";

		$urlencodemsg =  urlencode("$message");

		//$urlencodemsg =  str_replace(" ","%20",str_replace("\n","%0A","$message"));//encode msg to fit for url-encoding

		$smsurl="http://$serverurl?to=$st_hpnumber&msg=$urlencodemsg";

		$execSms = file_get_contents($smsurl); // create or execute a new cURL resource

		//print url and result on screen for debugging purposes

		//print_r($smsurl);

		//print_r("\r");

		//print_r($execSms);



		

		?>

		<form method="POST" action="mob-register-update.php" name="register">
			<div style="padding: 10%;">
			   <input type="hidden" id="generatedSmsCode" class="input-text" name="smsCode" required placeholder="Enter ID Number or Scan Barcode" value="<?php echo $st_smsCode; ?>"/>

			   <input readonly value="<?php echo $st_id; ?>" type="hidden" id="stud_id" class="input-text" name="stud_id"/>

			   <input readonly value="<?php echo $st_firstname; ?>" type="hidden" class="input-text" id="stud_firstname" name="stud_firstname"/>

			   <input readonly value="<?php echo $st_middlename; ?>" type="hidden" class="input-text" id="stud_middlename" name="stud_middlename"/>

			   <input readonly value="<?php echo $st_lastname; ?>" type="hidden" class="input-text" id="stud_lastname"  name="stud_lastname" />

			   <input readonly value="<?php echo $st_gender; ?>" type="hidden" class="input-text" name="stud_gender" id="stud_gender" />

			   <input readonly value="<?php echo $st_dob; ?>" type="hidden" class="input-text" id="stud_dob"  name="stud_dob"/>

			   <input readonly value="<?php echo $st_email; ?>" type="hidden" class="input-text" id="stud_email"  name="stud_email"/>

			   <input readonly value="<?php echo $st_hpnumber; ?>" type="hidden" class="input-text id="stud_hpnumber"  name="stud_hpnumber"/>

			   <input readonly value="<?php echo $st_address; ?>" type="hidden" class="input-text" id="stud_address"  name="stud_address"/>

			   <input readonly value="<?php echo $st_section; ?>" type="hidden" class="input-text" id="stud_section"  name="stud_section"/></label>

			   <input readonly value="<?php echo $st_instructor; ?>" type="hidden" class="input-text" id="stud_instructor"  name="stud_instructor"/>

			   <input readonly value="<?php echo $st_subject; ?>" type="hidden" class="input-text" id="stud_subject"  name="stud_subject"/>

			   </br>
			   <?php $confirmMessage = "successfully";
			   if(strstr($execSms, $confirmMessage)) { ?>
					Your Verification code was sent to <b><?php echo $st_hpnumber; ?></b>.</br>It may took up to 3 minutes to arrive.</br>Click REGISTER to proceed or BACK if you want to change phone number or re-submit.</a></br></br>
					
					<label style="border-style: solid; color: #016635; padding:3px; width: 100%;">SMS Verification code:</br><input type="number" style="min-width:100%; min-height:40px; padding:5px" class="input-text" maxlength="4" id="sms_ota"  name="sms_ota" required placeholder="Enter SMS OTA"/></label></br></br> 

					<input type="submit" name="submit" class="input-button" value="REGISTER" style="min-width:100px; min-height:40px; background-color: #016635;"/> &nbsp;&nbsp <a href="javascript:history.back()"><input type="button" class="input-button" value="BACK" style="min-width:100px; min-height:40px; background-color: #016635;"/></a>
			   <?php }else{ ?>
					We cannot process your verification code at the moment.</br>You are trying to reach <b><?php echo $st_hpnumber; ?></b> via <b><?php echo $serverurl; ?></b>.</br> Click REGISTER to proceed or BACK if you want to change phone number or re-submit. </br></br>
					<a href="javascript:history.back()"><input type="button" class="input-button" value="BACK" style="min-width:100px; min-height:40px; background-color: #016635;"/></a>
			   <?php }?>
			   </br></br></br></br> 
			</div>
		</form>

	</div>

</body>

</html>



