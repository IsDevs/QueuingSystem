<?php
include 'config/config.php';
include 'classes/class.students.php';


$student = new Students();

if(isset($_REQUEST['submit'])){
	extract($_REQUEST);
	$st_smsCode = $_POST['smsCode'];
	$st_id = $_POST['stud_id'];
	$st_firstname = $_POST['stud_firstname'];
	$st_middlename = $_POST['stud_middlename'];
	$st_lastname = $_POST['stud_lastname'];
	$st_gender = $_POST['stud_gender'];
	$st_dob = $_POST['stud_dob'];
	$st_email = $_POST['stud_email'];
	$st_hpnumber = $_POST['stud_hpnumber'];
	$st_parenthpnumber = $_POST['stud_parenthpnumber'];
	$st_address = $_POST['stud_address'];
	$st_section = $_POST['stud_section'];
	$st_instructor = $_POST['stud_instructor'];
	$st_subject = $_POST['stud_subject'];
	$sms_ota = $_POST['sms_ota'];
	
	if ($st_smsCode === $sms_ota){
		$addNew = $student->addNew($st_id, $st_firstname,$st_middlename,$st_lastname,$st_gender,$st_dob,$st_email,$st_hpnumber,$st_parenthpnumber,$st_address,$st_section,$st_instructor,$st_subject);
		
		if($addNew){//all good
			echo("<script>window.location = 'mob-register-final.php';</script>");
		}
		else{ //an error occured
			echo("<script>window.location = 'mob-register-xfinal.php';</script>");
		}
	} else {
		echo("<script>alert('ERROR: One-time-authentication (OTA) is invalid!')</script>");
		echo("<script>window.location = 'mob-register-xfinal.php';</script>");
	}
}
?>

