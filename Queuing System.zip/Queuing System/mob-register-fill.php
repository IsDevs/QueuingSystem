<?php
include 'config/config.php';
include 'classes/class.students.php';
include 'classes/class.site.global.php';

$student = new Students();
$site=new Site();
$st_id = $_GET['stud_id'];

//auto fill student
$stud = $student->get_studentbyLikeId($st_id);
if($stud != false){
	foreach($stud as $val){
		$st_firstname = $val['fName'];
		$st_middlename = $val['mName'];
		$st_lastname = $val['lName'];
		$st_gender = $val['gender'];
		$st_dob = $val['birthdate']; 
		$st_email = $val['email'];
		$st_hpnumber = $val['hpNumber'];
		$st_parenthpnumber = $val['parentHpNumber'];
		$st_address = $val['address'];
	}
	//echo '<script type="text/javascript">alert("'.count($stud).'")</script>';
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Register - <?php echo $site->getTitle(); ?></title>
	<link rel="icon" type="image/png" href="favicon.ico">
	<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    <link rel="stylesheet" type="text/css" href="css/stylesheet.css">
    <link rel="stylesheet" href="css/responsive-stylesheet.css">
	<script src="https://apis.google.com/js/platform.js" async defer></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="script/script.js"></script>
	<script>
	function onInputClick(e){
		var r = window.prompt("Enter date of birth (YYYY-MM-DD)", "1994-12-21");
		if(/[\d]{4}-[\d]{1,2}-[\d]{1,2}/.test(r)){
			//date ok
			e.value=r;
			var split=e.value.split("-");
			var date=new Date(parseInt(split[0]),parseInt(split[1])-1,parseInt(split[2]));
		}else{
			alert("Invalid date. Try again.");
		}
	}
	</script>
</head>
<body>
<div style="padding:15px;">
    <img src="images/usls.png" style="width: 100%; min-height: 10px;"></br></br></br>
	<form action="mob-register-confirm.php" method="POST" name="register">
		<div style="padding: 10%;">
		   <input type="hidden" id="generatedSmsCode" class="input-text" name="smsCode" required placeholder="Enter ID Number or Scan Barcode" value="<?php echo (rand(1000,9999)); ?>" />
		   <label style="border-style: solid; color: #016635; padding:3px; width: 100%;">ID Number:<input type="number" style="min-width:100%; min-height:40px; padding:5px" id="stud_id" class="input-text" name="stud_id" required placeholder="Enter ID Number or Scan Barcode" value="<?php echo $st_id; ?>" /></label></br></br>
           <label style="border-style: solid; color: #016635; padding:3px; width: 100%;">First Name:<input type="text" style="min-width:100%; min-height:40px; padding:5px" class="input-text" id="stud_firstname" name="stud_firstname" required placeholder="Enter First Name" value="<?php echo $st_firstname; ?>" /></label></br></br>
           <label style="border-style: solid; color: #016635; padding:3px; width: 100%;">Middle Name:<input type="text" style="min-width:100%; min-height:40px; padding:5px" class="input-text" id="stud_middlename" name="stud_middlename" required placeholder="Enter Middle Name" value="<?php echo $st_middlename; ?>" /></label></br></br>
           <label style="border-style: solid; color: #016635; padding:3px; width: 100%;">Last Name:<input type="text" style="min-width:100%; min-height:40px; padding:5px" class="input-text" id="stud_lastname"  name="stud_lastname" required placeholder="Enter Last Name" value="<?php echo $st_lastname; ?>" /></label></br></br> 
           <label style="border-style: solid; color: #016635; padding:3px; width: 100%;">Gender:<select name="stud_gender" id="" style="min-width:100%; min-height:40px; padding:5px"  required> 
				<option value="0" <?php if($st_gender=="0") echo 'selected="selected"'; ?> >Select Gender</option>
				<option value='Female' <?php if($st_gender=="Female") echo 'selected="selected"'; ?> >Female</option>
				<option value='Male' <?php if($st_gender=="Male") echo 'selected="selected"'; ?> >Male</option>
		   </select></label></br></br>
		   <label style="border-style: solid; color: #016635; padding:3px; width: 100%;">Date of Birth:(YYYY-MM-DD)<input type="text" style="min-width:100%; min-height:40px; padding:5px" onclick="onInputClick(this)" class="input-text" id="stud_dob"  name="stud_dob" required placeholder="Enter Birth Date"  value="<?php echo $st_dob; ?>" /></label></br></br>
           <label style="border-style: solid; color: #016635; padding:3px; width: 100%;">E-mail:<input type="email" style="min-width:100%; min-height:40px; padding:5px" class="input-text" id="stud_email"  name="stud_email" required placeholder="Enter Email" value="<?php echo $st_email; ?>" /></label></br></br>
           <label style="border-style: solid; color: #016635; padding:3px; width: 100%;">Phone Number:<input type="tel" style="min-width:100%; min-height:40px; padding:5px" class="input-text id="stud_hpnumber"  name="stud_hpnumber" required placeholder="Enter Phone Number (ex: 09121234567)" value="<?php echo $st_hpnumber; ?>" /></label></br></br>
           <label style="border-style: solid; color: #016635; padding:3px; width: 100%;">Parent Phone Number:<input type="tel" style="min-width:100%; min-height:40px; padding:5px" class="input-text id="stud_parenthpnumber"  name="stud_parenthpnumber" required placeholder="Enter Phone Number (ex: 09121234567)" value="<?php echo $st_parenthpnumber; ?>" /></label></br></br>
           <label style="border-style: solid; color: #016635; padding:3px; width: 100%;">Address:<input type="text" style="min-width:100%; min-height:40px; padding:5px" class="input-text" id="stud_address"  name="stud_address" required placeholder="Enter Address" value="<?php echo $st_address; ?>" /></label></br></br>
           <label style="border-style: solid; color: #016635; padding:3px; width: 100%;">Course and Section:<input type="text" style="min-width:100%; min-height:40px; padding:5px" class="input-text" id="stud_section"  name="stud_section" required placeholder="Enter Course and Section" value="<?php echo $st_section; ?>" /></label></br></br>
           <label style="border-style: solid; color: #016635; padding:3px; width: 100%;">Instructor:<input type="text" style="min-width:100%; min-height:40px; padding:5px" class="input-text" id="stud_instructor"  name="stud_instructor" required placeholder="Enter Instructor Name" value="<?php echo $st_instructor; ?>" /></label></br></br>
           <label style="border-style: solid; color: #016635; padding:3px; width: 100%;">Subject:<input type="text" style="min-width:100%; min-height:40px; padding:5px" class="input-text" id="stud_subject"  name="stud_subject" required placeholder="Enter Subject" value="<?php echo $st_subject; ?>" /></label></br></br> 
		   <input type="submit" name="submit" class="input-button" value="Authenticate" style="min-width:100px; min-height:40px; background-color: #016635;" title="Click AUTHENTICATE BUTTON to retrieve your one-time-authentication(OTA) Code" />  </br></br></br></br>
		</div>
	</form>
</div>
</body>
</html>