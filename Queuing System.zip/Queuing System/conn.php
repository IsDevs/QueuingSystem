<?php
mysql_select_db('hackathon1',mysql_connect('localhost','hackathon1','x5Fx86Q3deAWZ9Pc'))or die(mysql_error());
?>