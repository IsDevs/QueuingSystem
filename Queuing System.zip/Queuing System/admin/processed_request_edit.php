<?php
	include 'includes/session.php';

	if(isset($_POST['edit'])){
		$id = $_POST['id'];
		$payment_stat = $_POST['payment_status'];
		
		$sql = "UPDATE transaction SET payment_status = '$payment_stat' WHERE id = '$id'";
		if($conn->query($sql)){
			$_SESSION['success'] = 'Successfully Updated';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}

	}
	else{
		$_SESSION['error'] = 'Select to edit first';
	}

	header('location: processed_request.php');
?>