<?php
	include 'includes/session.php';

	if(isset($_POST['edit'])){
		$id = $_POST['id'];
        $date = $_POST['date'];
		
        $req_status = $_POST['req_status'];
        
		
		$sql = "INSERT INTO transaction (req_info_id, req_status, date) VALUES ('$id','$req_status', '$date')";
		if($conn->query($sql)){
			$_SESSION['success'] = 'Successfully Updated ';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}

	}
	else{
		$_SESSION['error'] = 'Select to edit first';
	}

	header('location: pending_request.php');
?>