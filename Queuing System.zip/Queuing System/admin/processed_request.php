<?php include 'includes/session.php'; ?>
<?php include 'includes/header.php'; ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php include 'includes/navbar.php'; ?>
  <?php include 'includes/menubar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <strong>Processed Application Request List</strong>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Request Status</li>
          <li class="active">Pending Request</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <?php
        if(isset($_SESSION['error'])){
          echo "
            <div class='alert alert-danger alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-warning'></i> Error!</h4>
              ".$_SESSION['error']."
            </div>
          ";
          unset($_SESSION['error']);
        }
        if(isset($_SESSION['success'])){
          echo "
            <div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-check'></i> Success!</h4>
              ".$_SESSION['success']."
            </div>
          ";
          unset($_SESSION['success']);
        }
      ?>
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              </div>
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <th class="hidden"></th>
                  
                  <th>Processing Date</th>
                  <th>Name</th>
                  <th>License Type</th>
                  
                  
                </thead>
                <tbody>
                  <?php
                    $sql = "SELECT * FROM transaction where req_status = 'Processed'";
                    $query = $conn->query($sql);
                    while($row = $query->fetch_assoc()){
                        $id = $row['id'];
                        $req_id = $row['req_info_id'];
                        
                            $sql1 = "SELECT * FROM application_info";
                            $query1 = $conn->query($sql1);
                            $row1 = $query1->fetch_assoc();
                            $id = $row1['id'];
                        
                            $sql2 = "SELECT * FROM request_form_info where id = '$req_id'";
                            $query2 = $conn->query($sql2);
                            $row2 = $query2->fetch_assoc();
                            $form_id = $row2['req_form_id'];
                        
                            $sql3 = "SELECT * FROM forms_info where id = '$form_id'";
                            $query3 = $conn->query($sql3);
                            $row3 = $query3->fetch_assoc();
                            
                      echo "
                        <tr>
                          <td class='hidden'></td>
                         <td>".$row['date']."</td>
                         
                          <td>".$row1['lastname'].',&nbsp'.$row1['firstname']."</td>
                          <td>".$row1['license']."</td>
                         
                          
                        
                          
                         
                        </tr>
                      ";
                    }
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>   
  </div>
    
  <?php include 'includes/footer.php'; ?>
  <?php include 'includes/pending_request_modal.php'; ?>
</div>
<?php include 'includes/scripts.php'; ?>
<script>
$(function(){
  $(document).on('click', '.edit', function(e){
    e.preventDefault();
    $('#edit').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });

});

function getRow(id){
  $.ajax({
    type: 'POST',
    url: 'pending_request_row.php',
    data: {id:id},
    dataType: 'json',
    success: function(response){
      $('.id').val(response.id);

      $('#edit_payment_status').val(response.payment_status);
    
    }
  });
}
</script>
</body>
</html>
