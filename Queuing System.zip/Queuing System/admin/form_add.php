<?php
	include 'includes/session.php';

	if(isset($_POST['add'])){
		$form_type = $_POST['request_type'];
		$payment = $_POST['payment'];
        $duration = $_POST['duration'];
        
	
		$sql = "INSERT INTO forms_info (request_type, payment, duration) VALUES ('$form_type', '$payment', '$duration Days')";
		if($conn->query($sql)){
			$_SESSION['success'] = 'Added successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}

	}
	else{
		$_SESSION['error'] = 'Fill up add form first';
	}

	header('location: form.php');
?>