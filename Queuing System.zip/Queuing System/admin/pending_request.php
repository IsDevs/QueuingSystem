<?php include 'includes/session.php'; ?>
<?php include 'includes/header.php'; ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <?php include 'includes/navbar.php'; ?>
  <?php include 'includes/menubar.php'; ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <strong>Pending Application Request List</strong>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Request Status</li>
          <li class="active">Pending Request</li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <?php
        if(isset($_SESSION['error'])){
          echo "
            <div class='alert alert-danger alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-warning'></i> Error!</h4>
              ".$_SESSION['error']."
            </div>
          ";
          unset($_SESSION['error']);
        }
        if(isset($_SESSION['success'])){
          echo "
            <div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-check'></i> Success!</h4>
              ".$_SESSION['success']."
            </div>
          ";
          unset($_SESSION['success']);
        }
      ?>
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header with-border">
              </div>
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <th class="hidden"></th>
                  
                  <th>Processing Date</th>
                  <th>Name</th>
                     <th>Age</th>
                     <th>Nationality</th>
                     <th>Address</th>
                     <th>Contact Info</th>
                     <th>Gender</th>
                  <th>License Type</th>
                    <th>Action</th>
                  
                  
                </thead>
                <tbody>
                  <?php
                    
                        
                            $sql1 = "SELECT * FROM application_info";
                            $query1 = $conn->query($sql1);
                            while($row1 = $query1->fetch_assoc()){
                            $id = $row1['id'];
                        
                            
                            
                      echo "
                        <tr>
                          <td class='hidden'></td>
                         <td>".$row['date']."</td>
                         
                          <td>".$row1['lastname'].',&nbsp'.$row1['firstname']."</td>
                          <td>".$row1['age']."</td>
                          <td>".$row1['nationality']."</td>
                          <td>".$row1['address']."</td>
                          <td>".$row1['contact_info']."</td>
                          <td>".$row1['gender']."</td>
                          
                          <td>".$row1['license']."</td>
                         <td>
                            <button class='btn btn-success btn-sm edit btn-flat' data-id='".$row1['id']."'><i class='fa fa-edit'></i> Update</button>
                            
                          </td>
                          
                        
                        
                        </tr>
                      ";
                    }
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </section>   
  </div>
    
  <?php include 'includes/footer.php'; ?>
  <?php include 'includes/pending_request_modal.php'; ?>
</div>
<?php include 'includes/scripts.php'; ?>
<script>
$(function(){
  $(document).on('click', '.edit', function(e){
    e.preventDefault();
    $('#edit').modal('show');
    var id = $(this).data('id');
    getRow(id);
  });

});

function getRow(id){
  $.ajax({
    type: 'POST',
    url: 'pending_request_row.php',
    data: {id:id},
    dataType: 'json',
    success: function(response){
      $('.id').val(response.id);
      $('.firstname').val(response.firstname);
         $('.middlename').val(response.middlename);
         $('.lastname').val(response.lastname);
         $('contact_info').val(response.contact_info);
      $('#edit_req_status').val(response.req_status);
    
    }
  });
}
</script>
</body>
</html>
