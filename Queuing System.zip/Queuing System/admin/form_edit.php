<?php
	include 'includes/session.php';

	if(isset($_POST['edit'])){
		$id = $_POST['id'];
		$payment = $_POST['payment'];
		$duration = $_POST['duration'];
		
        
		$sql = "UPDATE forms_info SET payment = '$payment', duration = '$duration Days' WHERE id = '$id'";
		if($conn->query($sql)){
			$_SESSION['success'] = 'Updated successfully';
		}
		else{
			$_SESSION['error'] = $conn->error;
		}

	}
	else{
		$_SESSION['error'] = 'Select to edit first';
	}

	header('location: form.php');
?>