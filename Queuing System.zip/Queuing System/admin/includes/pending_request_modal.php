<!-- Edit -->
<div class="modal fade" id="edit">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title"><b>Update Details</b></h4>
            </div>
            <div class="modal-body">
              <form class="form-horizontal" method="POST" action="pending_request_edit.php">
                <input type="hidden" class="id" name="id"> 
                  
                  <input type="text" class="id" name="firstname"> 
                   <input type="hidden" class="id" name="middlename"> 
                   <input type="hidden" class="id" name="lastname"> 
                   <input type="text" class="contact_info" name="contact_info"> 
                  
                  
                    <div class="form-group">
                    <label for="edit_request_type" class="col-sm-3 control-label">Set Date</label>

                    <div class="col-sm-9">
                      <input type="date" class="span9" id="edit_request_type" name="date">
                    </div>
                </div>
                  
                 
                    <div class="form-group">
                    <label for="edit_req_status" class="col-sm-3 control-label">Request Status</label>
                        
                     <div class="col-sm-9"> 
                      <select class="form-control" name="req_status" id="req_status">
                        <option selected id="edit_req_status"></option>
                        <option value="Processed">Process</option>
                        <option value="Decline">Decline</option>
                      </select>
                    </div>
                    </div>
                  <!-- End -->
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
              <button type="submit" class="btn btn-success btn-flat" name="edit"><i class="fa fa-check-square-o"></i> Update</button>
              </form>
            </div>
        </div>
    </div>
</div>




     