<!-- Add -->
<div class="modal fade" id="addnew">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title"><b>Add New Form Detail</b></h4>
            </div>
            <div class="modal-body">
              <form class="form-horizontal" method="POST" action="form_add.php">
                  
                   		  <div class="form-group">
                  	<label for="request_type" class="col-sm-3 control-label">Form Type</label>

                  	<div class="col-sm-9">
                    	<input type="text" class="form-control" id="request_type" name="request_type" required>
                  	</div>
                </div>
                <div class="form-group">
                  	<label for="payment" class="col-sm-3 control-label">Payment</label>

                  	<div class="col-sm-9">
                    	<input type="number" class="form-control" id="payment" name="payment"  required>
                  	</div>
                </div>
                <div class="form-group">
                  	<label for="duration" class="col-sm-3 control-label">Processing Duration</label>

                  	<div class="col-sm-9">
                      <textarea class="form-control" name="duration" id="duration"></textarea>
                  	</div>
                </div>
                
                  
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
              <button type="submit" class="btn btn-primary btn-flat" name="add"><i class="fa fa-save"></i> Save</button>
              </form>
            </div>
        </div>
    </div>
</div>

<!-- Edit -->
<div class="modal fade" id="edit">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title"><b>Edit Employee Details</b></h4>
            </div>
            <div class="modal-body">
              <form class="form-horizontal" method="POST" action="form_edit.php">
                <input type="hidden" class="id" name="id">
                  <!-- Start -->
                  
                <div class="form-group">
                    <label for="edit_request_type" class="col-sm-3 control-label">Request Type</label>

                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="edit_request_type" name="request_type">
                    </div>
                </div>
                <div class="form-group">
                    <label for="edit_payment" class="col-sm-3 control-label">Payment</label>

                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="edit_payment" name="payment">
                    </div>
                </div>
                <div class="form-group">
                    <label for="edit_duration" class="col-sm-3 control-label">Duration</label>

                    <div class="col-sm-9">
                      <textarea class="form-control" name="duration" id="edit_duration"></textarea>
                    </div>
                </div>
               
        
                  <!-- End -->
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
              <button type="submit" class="btn btn-success btn-flat" name="edit"><i class="fa fa-check-square-o"></i> Update</button>
              </form>
            </div>
        </div>
    </div>
</div>




     