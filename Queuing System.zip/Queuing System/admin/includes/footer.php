<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>All rights reserved</b>
    </div>
    <strong>Copyright &copy; 2018 <a >MASSKARA Hackathon</a>&nbsp;ll&nbsp;<a >E-Document Request System</a></strong>
</footer>