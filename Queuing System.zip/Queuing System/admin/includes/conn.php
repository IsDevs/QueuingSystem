<?php
	$conn = new mysqli('localhost', 'hackathon1', 'x5Fx86Q3deAWZ9Pc', 'hackathon1');

	if ($conn->connect_error) {
	    die("Connection failed: " . $conn->connect_error);
	}
	
?>