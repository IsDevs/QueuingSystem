<?php
include 'config/config.php';
include 'classes/class.students.php';
include 'classes/class.site.global.php';

$student = new Students();
$site=new Site();

?>
<!DOCTYPE html>
<html>
<head>
	<title>Register - <?php echo $site->getTitle(); ?></title>
	<link rel="icon" type="image/png" href="favicon.ico">
	<meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
    <link rel="stylesheet" type="text/css" href="css/stylesheet.css">
    <link rel="stylesheet" href="css/responsive-stylesheet.css">
	<script src="https://apis.google.com/js/platform.js" async defer></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="script/script.js"></script>
	<script>
	$('#stud_id').on('focusout', function(event) {
		// Stop form from submitting normally
		event.preventDefault();
		$("#searchForm").trigger('submit');
	});
	</script>
	<script>
	// Attach a submit handler to the form
	$( "#searchForm" ).submit(function( event ) {
	 
	  // Stop form from submitting normally
	  event.preventDefault();
	 
	  // Get some values from elements on the page:
	  var $form = $( this ),
		term = $form.find( "input[name='stud_id']" ).val(),
		url = $form.attr( "action" );
	 
	  // Send the data using post
	  var posting = $.post( url, { stud_id: term } );
	 
	  // Put the results in a div
	  posting.done(function( data ) {
		var content = $( data ).find( "#content" );
		$( "#result" ).empty().append( content );
	  });
	});
	</script>
	
</head>
<body > 
 
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>jQuery.post demo</title>
  <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
</head>
<body> 
   
<div style="padding:15px;">
		<img src="images/usls.png" style="width: 100%; min-height: 10px;"></br></br></br>
		<form action="mob-register-fill.php"> 
				<div style="padding: 10%;">
					<label style="border-style: solid; color: #016635; padding:3px; width: 100%;">ID Number:  <input type="number" style="min-width:100%; min-height:40px; padding:5px" id="stud_id" class="input-text" name="stud_id" required placeholder="Enter ID Number or Scan Barcode" onChange="javascript: submitform()" /><!--onChange="searchId();"--> </label></br></br>
					<input type="submit" style="min-width:100px; min-height:40px; background-color: #016635;" name="submit" class="input-button" value="Next" title="Click NEXT BUTTON to proceed to next step" />  </br></br>
				</div> 
		</form>
</div>
 <script>
		$('#stud_id').focus();
	</script>
</body>
</html>
</div>
</body>
</html>